import React from 'react'
//import AccountBalanceIcon from '@material-ui/icons/AccountBalance';

function Home() {
    return (
        <div>
            <div  className="introimg">
                <img src={"https://images.unsplash.com/photo-1553729459-efe14ef6055d?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80"} 
                 class="img-fluid"  alt="..." style={{width:"100%",height:"600px",borderTop:"8px solid #7e9293"}}></img>
            </div>
             
        </div>
    )
}

export default Home
